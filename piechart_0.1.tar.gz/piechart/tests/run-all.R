library(testthat)
library(piechart)
test_package("piechart")
